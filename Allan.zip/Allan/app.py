from Tree import Tree
from Node import Node 

tree = Tree()

a = Node("A")
b = Node("B")
c = Node("C")
d = Node("D")

tree.addNode(a)

tree.addNode(b, a, "left")

tree.addNode(c, b, "left")

tree.addNode(d, a, "right")

tree.printTree(a)