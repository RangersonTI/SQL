class Tree:
    def __init__(self):
        self.__root = None

    def isRoot(self, node):
        return node == self.__root

    def isEmpty(self):
        return self.__root == None

    def isExternal(self, node):
        return node.getLeftChild() == None and node.getRightChild() == None

    def isInternal(self, node):
        return node.getLeftChild() != None or node.getRightChild() != None

    def parent(self, node):
        return node.getParent()

    def addNode(self, node, parent=None, side=None):
        if self.isEmpty() and parent == None:
            self.__root = node
        else:
            if side == "left":
                parent.addLeftChild(node)
            elif side == "right":
                parent.addRightChild(node)

    def printTree(self, node):
        leftChild = node.getLeftChild()
        rightChild = node.getRightChild()

        if leftChild != None:
            self.printTree(leftChild)
        
        if rightChild != None:
            self.printTree(rightChild)

        print(f"({node})", end=" ")
