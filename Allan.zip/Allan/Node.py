class Node:
    def __init__(self, value = "", parent = None):
        self.__value = value
        self.__parent = parent
        self.__leftChild = None
        self.__rightChild = None
    
    def __str__(self):
        return f"{self.__value}"
    
    def setValue(self, value):
        self.__value = value
        
    def getValue(self):
        return self.__value
    
    def setParent(self, parent):
        self.__parent = parent
        
    def getParent(self):
        return self.__parent

    def addLeftChild(self, leftChild):
        leftChild.setParent(self)
        self.__leftChild = leftChild

    def getLeftChild(self):
        return self.__leftChild
    
    def addRightChild(self, rightChild):
        rightChild.setParent(self)
        self.__rightChild = rightChild
    
    def getRightChild(self):
        return self.__rightChild
